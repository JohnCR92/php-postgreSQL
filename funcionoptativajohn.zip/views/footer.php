<div class="footer">
   		<p class="text-center bg-info">Copyright (c) 2016</p>
 	</div>
</body>
</html>
