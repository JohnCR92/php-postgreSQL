<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>User App</title>
	<!-- CSS BOOTSTRAP -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme-min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<!-- JS BOOTSTRAP -->
	<script type="text/javascript" src="js/jquery.1.8.1.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/login.js"></script>
</head>
<body>
