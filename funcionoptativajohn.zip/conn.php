<?php 
	$conn=pg_connect("dbname=user_db user=postgres password=111111")or die("Cannnot db,please check your connection string");
?>

